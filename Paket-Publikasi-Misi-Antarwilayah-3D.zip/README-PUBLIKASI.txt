# Misi Antarwilayah 3D — Publikasi Gratis

Paket ini siap diunggah ke GitHub Pages agar game dapat dibuka lewat tautan publik.

## Cara membuat tautan publik dengan GitHub Pages

1. Masuk atau daftar di https://github.com
2. Buat repository baru bernama `misi-antarwilayah-3d`.
3. Pilih **Public**.
4. Unggah file `index.html` dari paket ini ke repository tersebut.
5. Buka **Settings → Pages**.
6. Pada bagian **Build and deployment**, pilih **Deploy from a branch**.
7. Pilih branch **main** dan folder **/(root)**, lalu tekan **Save**.
8. Tunggu beberapa menit. GitHub akan menampilkan alamat situs, biasanya:
   `https://NAMA-USERNAME.github.io/misi-antarwilayah-3d/`

Ganti `NAMA-USERNAME` dengan nama pengguna GitHub Anda. Alamat di atas hanya contoh, bukan tautan yang sudah diterbitkan.

## Catatan
- File `index.html` adalah game yang bisa dijalankan langsung di browser.
- Setelah diterbitkan, siapa pun yang memiliki tautan publik dapat membuka game.
- Saya belum menerbitkan situs ke akun GitHub Anda, jadi tautan publik final baru tersedia setelah langkah di atas dilakukan.
